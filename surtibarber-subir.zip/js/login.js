const $=s=>document.querySelector(s);let setup=false;
fetch('/api/status').then(r=>r.json()).then(d=>{if(!d.configured){setup=true;$('#tkw').hidden=false;$('#go').textContent='Crear administrador';$('#p').autocomplete='new-password';$('#err').textContent='Primera vez: crea el administrador (contraseña de 12+ caracteres).'}}).catch(()=>{});
const call=async(u,b)=>{const r=await fetch(u,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});return[r,await r.json().catch(()=>({}))]};
$('#f').onsubmit=async e=>{e.preventDefault();const b={user:$('#u').value,password:$('#p').value};if(setup)b.token=$('#tk').value;
let[r,d]=await call(setup?'/api/setup':'/api/login',b);if(r.ok&&setup)[r,d]=await call('/api/login',b);
if(r.ok)location.href='/admin.html';else{$('#err').textContent=d.error||'Error';$('#p').value='';$('#p').focus()}};