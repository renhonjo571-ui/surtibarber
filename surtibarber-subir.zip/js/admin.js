let CSRF='';const api=(u,o={})=>fetch(u,{...o,headers:{'content-type':'application/json','x-csrf':CSRF}}).then(async r=>{if(r.status===401){location.replace('/login.html');throw 0}const d=await r.json().catch(()=>({}));if(!r.ok){alert(d.error||'Error');throw 0}return d});
const S={p:[],o:[],ev:[],sales:0,oc:0,ec:0};
async function refresh(){const[a,b]=await Promise.all([api('/api/products'),api('/api/stats')]);S.p=a.products;S.o=b.orders;S.ev=b.top;S.sales=b.sales;S.oc=b.oc;S.ec=b.ec;render()}
const $=s=>document.querySelector(s),money=n=>'$'+Number(n).toFixed(2);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ph=n=>'data:image/svg+xml;utf8,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><rect width="400" height="300" fill="#1a1e28"/><text x="200" y="168" text-anchor="middle" font-family="Georgia,serif" font-size="52" fill="#d09255">${esc(n.trim().slice(0,2).toUpperCase())}</text></svg>`);
let editId=null,imgData='';
function render(){const ps=S.p,os=S.o,es=S.ev;
const av=ps.filter(p=>p.stock>0).length,sales=S.sales;
$('#mt').innerHTML=[['Agregados al carrito',S.ec],['Pedidos',S.oc],['Ventas',money(sales)],['Disponibles',av+' de '+ps.length],['Agotados',ps.length-av]].map(x=>`<div class="m"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');
$('#pb').innerHTML=ps.map(p=>`<tr><td><img alt="" src="${p.img?esc(p.img):ph(p.name)}"></td><td>${esc(p.name)}</td><td>${esc(p.cat)}</td><td>${money(p.price)}</td><td>${p.stock}</td><td><span class="tag ${p.stock>0?'o':'x'}">${p.stock>0?'Disponible':'Agotado'}</span></td><td><button class="btn" data-e="${p.id}">Editar</button><button class="btn d" data-x="${p.id}">Eliminar</button></td></tr>`).join('')||'<tr><td colspan="7" class="empty">Sin productos. Abre la tienda una vez para cargar el catálogo de ejemplo, o crea uno nuevo.</td></tr>';
$('#ob').innerHTML=os.slice().reverse().slice(0,20).map(o=>`<tr><td>${esc(o.id)}</td><td>${new Date(o.date).toLocaleString('es-VE')}</td><td>${esc(o.name)}<br><small style="color:var(--mu)">${esc(o.phone)}</small></td><td>${esc(o.city)}</td><td>${o.items.map(i=>i.q+' x '+esc(i.name)).join('<br>')}</td><td>${money(o.total)}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">Aún no hay pedidos.</td></tr>';
const cnt=Object.fromEntries(es.map(e=>[e.name,e.n]));
$('#eb').innerHTML=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,8).map(x=>`<tr><td>${esc(x[0])}</td><td>${x[1]}</td></tr>`).join('')||'<tr><td colspan="2" class="empty">Sin registros todavía.</td></tr>';
$('#cats').innerHTML=[...new Set(ps.map(p=>p.cat))].map(c=>`<option value="${esc(c)}">`).join('')}
function openForm(id){editId=id;imgData='';const p=S.p.find(x=>x.id===id)||{name:'',price:'',stock:'',cat:'',img:'',feat:false};
$('#dt').textContent=id?'Editar producto':'Nuevo producto';fn.value=p.name;fp.value=p.price;fs.value=p.stock;fc.value=p.cat;fd.checked=!!p.feat;fi.value=p.img&&!p.img.startsWith('data:')?p.img:'';ff.value='';
pv.style.display=p.img?'block':'none';pv.src=p.img||'';if(p.img&&p.img.startsWith('data:'))imgData=p.img;$('#dg').showModal();fn.focus()}
$('#new').onclick=()=>openForm(null);$('#cc').onclick=()=>$('#dg').close();
ff.onchange=()=>{const f=ff.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const s=Math.min(1,600/im.width),c=document.createElement('canvas');c.width=im.width*s;c.height=im.height*s;c.getContext('2d').drawImage(im,0,0,c.width,c.height);imgData=c.toDataURL('image/jpeg',.8);pv.src=imgData;pv.style.display='block';fi.value=''};im.src=r.result};r.readAsDataURL(f)};
$('#pf').onsubmit=async()=>{const d={name:fn.value.trim(),price:+fp.value,stock:Math.max(0,Math.floor(+fs.value)),cat:fc.value.trim(),img:imgData||fi.value.trim(),feat:fd.checked};
await api(editId?'/api/products/'+editId:'/api/products',{method:editId?'PUT':'POST',body:JSON.stringify(d)});await refresh()};
document.addEventListener('click',async e=>{const t=e.target.closest('[data-e],[data-x]');if(!t)return;
if(t.dataset.e)openForm(t.dataset.e);
if(t.dataset.x&&confirm('¿Eliminar este producto? No se puede deshacer.')){await api('/api/products/'+t.dataset.x,{method:'DELETE'});await refresh()}});
$('#rst').onclick=async()=>{if(confirm('¿Borrar todos los pedidos y registros del carrito? No se puede deshacer.')){await api('/api/orders',{method:'DELETE'});await refresh()}};
$('#out').onclick=async()=>{await api('/api/logout',{method:'POST'}).catch(()=>{});location.href='/login.html'};
api('/api/me').then(d=>{CSRF=d.csrf;return refresh()});

document.addEventListener('error',e=>{const i=e.target;if(i.tagName==='IMG'&&!i.dataset.f){i.dataset.f=1;i.src=ph('?')}},true);