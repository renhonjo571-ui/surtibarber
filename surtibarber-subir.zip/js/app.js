const K={c:'sb_cart'};
const ld=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v??d}catch{return d}};
const sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ph=n=>'data:image/svg+xml;utf8,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1c2230"/><stop offset="1" stop-color="#12151c"/></linearGradient></defs><rect width="400" height="300" fill="url(#g)"/><circle cx="200" cy="140" r="70" fill="none" stroke="#f0562f" stroke-width="2" opacity=".7"/><text x="200" y="158" text-anchor="middle" font-family="Impact,Arial Narrow,sans-serif" font-size="56" fill="#f0562f">${esc(n.trim().slice(0,2).toUpperCase())}</text></svg>`);
const $=s=>document.querySelector(s),money=n=>'$'+Number(n).toFixed(2);
let cat='Todos',P=[];const prods=()=>P,cart=()=>ld(K.c,[]);
const load=()=>fetch('/api/products').then(r=>r.json()).then(d=>{P=d.products||[]}).catch(()=>{});
document.addEventListener('error',e=>{const i=e.target;if(i.tagName==='IMG'&&!i.dataset.f){i.dataset.f=1;i.src=ph(i.alt||'?')}},true);
const toast=t=>{const e=$('#toast');e.textContent=t;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),1800)};
function chips(){const cs=['Todos',...new Set(prods().map(p=>p.cat))];$('#chips').innerHTML=cs.map(c=>`<button class="chip" aria-pressed="${c===cat}" data-c="${esc(c)}">${esc(c)}</button>`).join('');
const star='<svg viewBox="0 0 24 24"><path d="M12 1c1 6 5 10 11 11-6 1-10 5-11 11-1-6-5-10-11-11 6-1 10-5 11-11Z"/></svg>';const t=cs.slice(1).map(c=>`<span>${esc(c)}</span>${star}`).join('');$('#mq').innerHTML=t+t+t+t}
function grid(){const l=prods().filter(p=>cat==='Todos'||p.cat===cat);
$('#grid').innerHTML=l.map(p=>`<article class="card"><div class="im"><img loading="lazy" alt="${esc(p.name)}" src="${p.img?esc(p.img):ph(p.name)}"></div><div class="bd"><small>${esc(p.cat)}</small><h3>${esc(p.name)}</h3>${p.stock>0?`<small>${p.stock} disponibles</small>${p.stock<=5?'<span class="low">¡Últimas unidades!</span>':''}`:'<span class="out">Agotado</span>'}<div class="row"><span class="price">${money(p.price)}</span><button class="btn" data-add="${p.id}" ${p.stock>0?'':'disabled'}>Agregar</button></div></div></article>`).join('')||'<p class="empty">No hay productos en esta categoría.</p>';reveal()}
let ci=0,ct;const feats=()=>{let f=prods().filter(p=>p.stock>0&&p.feat);if(!f.length)f=prods().filter(p=>p.stock>0);return f.slice(0,6)};
function car(){const f=feats();$('#sl').innerHTML=f.map(p=>`<div class="sl"><img alt="${esc(p.name)}" src="${p.img?esc(p.img):ph(p.name)}"><div class="cap"><div><small>${esc(p.cat)}</small><h3>${esc(p.name)}</h3></div><div style="display:flex;gap:.8rem;align-items:center"><span class="price">${money(p.price)}</span><button class="btn" data-add="${p.id}">Agregar</button></div></div></div>`).join('');
$('#dots').innerHTML=f.map((_,i)=>`<button data-g="${i}" aria-label="Diapositiva ${i+1}"></button>`).join('');go(0)}
function go(i){const n=feats().length;if(!n)return;ci=(i+n)%n;$('#sl').style.transform=`translateX(-${ci*100}%)`;document.querySelectorAll('#dots button').forEach((b,j)=>b.classList.toggle('on',j===ci));clearInterval(ct);ct=setInterval(()=>go(ci+1),5000)}
const cr=$('#car');cr.onmouseenter=()=>{clearInterval(ct);cr.classList.add('paused')};cr.onmouseleave=()=>{cr.classList.remove('paused');go(ci)};
$('#pv').onclick=()=>go(ci-1);$('#nx').onclick=()=>go(ci+1);let sx=null;cr.onpointerdown=e=>sx=e.clientX;cr.onpointerup=e=>{if(sx!==null&&Math.abs(e.clientX-sx)>45)go(ci+(e.clientX<sx?1:-1));sx=null};
function draw(){const c=cart(),ps=prods();let t=0,n=0;
$('#items').innerHTML=c.length?c.map(i=>{const p=ps.find(x=>x.id===i.id);if(!p)return'';t+=p.price*i.q;n+=i.q;return`<div class="it"><img alt="${esc(p.name)}" src="${p.img?esc(p.img):ph(p.name)}"><div>${esc(p.name)}<br><small>${money(p.price)}</small></div><div class="q"><button data-d="${p.id}" aria-label="Menos">−</button>${i.q}<button data-u="${p.id}" aria-label="Más">+</button></div></div>`}).join(''):'<p class="empty">Tu pedido está vacío.</p>';
$('#tot').textContent=money(t);$('#cnt').textContent=n}
function setQ(id,d){const p=prods().find(x=>x.id===id);if(!p)return;let c=cart();const i=c.find(x=>x.id===id);
if(!i&&d>0)c.push({id,q:1});else if(i){if(d>0&&i.q>=p.stock){toast('No hay más existencias');return}i.q+=d;if(i.q<=0)c=c.filter(x=>x!==i)}
sv(K.c,c);if(d>0){fetch('/api/events',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id})}).catch(()=>{});toast(p.name+' agregado')}draw()}
document.addEventListener('click',e=>{const t=e.target.closest('[data-add],[data-d],[data-u],[data-c],[data-g]');if(!t)return;
if(t.dataset.add){setQ(t.dataset.add,1);$('#cartBtn').animate([{transform:'scale(1.12)'},{transform:'none'}],{duration:320})}
if(t.dataset.u)setQ(t.dataset.u,1);if(t.dataset.d)setQ(t.dataset.d,-1);if(t.dataset.g)go(+t.dataset.g);
if(t.dataset.c){cat=t.dataset.c;chips();grid()}});
document.addEventListener('pointermove',e=>{const c=e.target.closest('.card,.ct');if(c){const r=c.getBoundingClientRect();c.style.setProperty('--mx',e.clientX-r.left+'px');c.style.setProperty('--my',e.clientY-r.top+'px')}});
const tog=o=>{$('#drawer').classList.toggle('open',o);$('#veil').classList.toggle('open',o);if(o){$('#msg').innerHTML='';draw()}};
$('#cartBtn').onclick=()=>tog(true);$('#close').onclick=$('#veil').onclick=()=>tog(false);addEventListener('keydown',e=>{if(e.key==='Escape')tog(false)});
$('#co').onsubmit=async e=>{e.preventDefault();const c=cart();if(!c.length){$('#msg').textContent='Agrega productos primero.';return}
const f=e.target,btn=f.querySelector('button');btn.disabled=true;
try{const r=await fetch('/api/orders',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:$('#nm').value,phone:$('#ph').value,city:$('#ct').value,items:c.map(i=>({id:i.id,q:i.q}))})});
const o=await r.json();if(!r.ok)throw new Error(o.error||'No se pudo registrar el pedido');
sv(K.c,[]);const txt=encodeURIComponent(`Hola SurtiBarber, mi pedido ${o.id}:\n`+o.items.map(i=>`${i.q} x ${i.name}`).join('\n')+`\nTotal: ${money(o.total)}\n${$('#nm').value} - ${$('#ct').value}`);
$('#msg').innerHTML=`<p class="ok">Pedido ${esc(o.id)} registrado.</p><a class="btn ghost" target="_blank" rel="noopener" href="https://wa.me/584247537557?text=${txt}">Enviar por WhatsApp</a>`;
f.reset();await load();draw();grid();car()}catch(x){$('#msg').textContent=x.message}finally{btn.disabled=false}};
const days=['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
const n=new Date(new Date().toLocaleString('en-US',{timeZone:'America/Caracas'})),d=n.getDay(),m=n.getHours()*60+n.getMinutes();
$('#days').innerHTML=days.slice(1).concat(days[0]).map(x=>`<div class="day ${days[d]===x?'t':''}"><span>${x}</span><span>${x==='Domingo'?'8:30 a. m. – 2:30 p. m.':'8:30 a. m. – 6:30 p. m.'}</span></div>`).join('');
const open=m>=510&&m<(d===0?870:1110);$('#st').textContent=open?'Abierto ahora':'Cerrado ahora';$('#st').className='st '+(open?'o':'c');
let io;function reveal(){io=io||new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add('on');io.unobserve(x.target)}}),{threshold:.1});
document.querySelectorAll('.card:not(.rv),.rv:not(.on)').forEach((el,i)=>{el.classList.add('rv');el.style.transitionDelay=(el.classList.contains('card')?(i%4)*70:0)+'ms';io.observe(el)})}
let clicks=0,tm;$('#logo').onclick=()=>{clicks++;clearTimeout(tm);if(clicks>=5){clicks=0;location.href='login.html';return}tm=setTimeout(()=>clicks=0,1200)};
load().then(()=>{chips();grid();car();draw();reveal()});