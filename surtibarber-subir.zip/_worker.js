// SurtiBarber - Cloudflare Pages (modo avanzado). Sin dependencias.
// Bindings necesarios: DB (D1), secreto SETUP_TOKEN.
const ITER=100000; // máximo permitido por WebCrypto en Workers
const enc=new TextEncoder();
const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
const unhex=h=>new Uint8Array(h.match(/../g).map(x=>parseInt(x,16)));
const rnd=n=>hex(crypto.getRandomValues(new Uint8Array(n)));
const sha=async s=>hex(await crypto.subtle.digest('SHA-256',enc.encode(s)));
const pbk=async(pw,salt)=>hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:unhex(salt),iterations:ITER},await crypto.subtle.importKey('raw',enc.encode(pw),'PBKDF2',false,['deriveBits']),256));
const eq=(a,b)=>{if(a.length!==b.length)return false;let r=0;for(let i=0;i<a.length;i++)r|=a.charCodeAt(i)^b.charCodeAt(i);return r===0};
const H=(s,m)=>({s,m});
const J=(o,s=200,h={})=>new Response(JSON.stringify(o),{status:s,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...h}});
const log=(ev,ip,x={})=>console.log(JSON.stringify({ev,ip,t:new Date().toISOString(),...x}));
const clean=(v,n)=>String(v||'').replace(/[\u0000-\u001f<>]/g,'').trim().slice(0,n);
const PID=/^p[a-z0-9]{1,20}$/;

const CSP="default-src 'none'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; style-src-attr 'unsafe-inline'; font-src https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'; object-src 'none'; upgrade-insecure-requests";
const SEC={'content-security-policy':CSP,'strict-transport-security':'max-age=31536000; includeSubDomains','x-content-type-options':'nosniff','x-frame-options':'DENY','referrer-policy':'strict-origin-when-cross-origin','permissions-policy':'camera=(), microphone=(), geolocation=(), payment=()','cross-origin-opener-policy':'same-origin'};

export default{async fetch(req,env){
  const u=new URL(req.url);
  if(u.protocol==='http:'){u.protocol='https:';return Response.redirect(u.href,301)}
  let r;
  try{r=u.pathname.startsWith('/api/')?await api(req,env,u):await site(req,env,u)}
  catch(e){
    if(e&&e.s)r=J({error:e.m},e.s);
    else{log('error',req.headers.get('cf-connecting-ip'),{path:u.pathname,msg:String(e&&e.message||e)});r=J({error:'Error interno'},500)}
  }
  r=new Response(r.body,r);
  for(const k in SEC)r.headers.set(k,SEC[k]);
  if(/^\/(login|admin)(\.html)?$/.test(u.pathname))r.headers.set('x-robots-tag','noindex, nofollow');
  return r}};

async function site(req,env,u){
  if(req.method!=='GET'&&req.method!=='HEAD')return new Response('Method not allowed',{status:405});
  if(/(^|\/)\.|\.(sql|toml|md|map|env|bak|log|txt~)$/i.test(u.pathname))return new Response('Not found',{status:404});
  const r=await env.ASSETS.fetch(req),h=new Headers(r.headers);
  h.set('cache-control',/\.(js|css|jpe?g|png|webp|svg|woff2?)$/.test(u.pathname)?'public, max-age=3600':'no-cache');
  return new Response(r.body,{status:r.status,headers:h});
}

async function rl(env,k,max,sec){
  if(Math.random()<.02)await env.DB.prepare('DELETE FROM hits WHERE t<?').bind(Date.now()-864e5).run();
  const r=await env.DB.prepare('SELECT COUNT(*) n FROM hits WHERE k=? AND t>?').bind(k,Date.now()-sec*1000).first();
  return r.n>=max}
const hit=(env,k)=>env.DB.prepare('INSERT INTO hits(k,t) VALUES(?,?)').bind(k,Date.now()).run();

function prod(b){
  const name=clean(b.name,80),cat=clean(b.cat,30),price=Number(b.price),stock=Math.floor(Number(b.stock));
  let img=String(b.img||'').trim();
  if(!name||!cat||!(price>=0&&price<=1e5)||!(stock>=0&&stock<=1e5))throw H(400,'Datos de producto inválidos');
  if(img&&!(/^https:\/\/[^\s"'<>]{1,500}$/.test(img)||(img.length<250000&&/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(img))))throw H(400,'Imagen inválida (usa https:// o sube un archivo)');
  return[name,Math.round(price*100)/100,stock,cat,b.feat?1:0,img]}

async function api(req,env,u){
  const p=u.pathname.slice(5),m=req.method,ip=req.headers.get('cf-connecting-ip')||'?',DB=env.DB;
  if(m!=='GET'&&req.headers.get('origin')!==u.origin)throw H(403,'Origen no permitido');
  const body=async()=>{const t=await req.text();if(t.length>400000)throw H(413,'Demasiado grande');try{const o=JSON.parse(t);if(!o||typeof o!=='object')throw 0;return o}catch{throw H(400,'JSON inválido')}};
  const ck=(req.headers.get('cookie')||'').match(/(?:^|; )__Host-sb=([a-f0-9]{64})/);
  const sess=async()=>ck?DB.prepare('SELECT csrf FROM sessions WHERE id=? AND exp>?').bind(await sha(ck[1]),Date.now()).first():null;
  const admin=async()=>{const s=await sess();if(!s)throw H(401,'No autorizado');if(m!=='GET'&&!eq(req.headers.get('x-csrf')||'',s.csrf))throw H(403,'CSRF inválido');return s};
  let x;

  if(p==='status'&&m==='GET')return J({configured:!!await DB.prepare('SELECT 1 x FROM admin').first()});

  if(p==='setup'&&m==='POST'){
    const b=await body();
    if(!env.SETUP_TOKEN||await DB.prepare('SELECT 1 x FROM admin').first())throw H(404,'No disponible');
    if(await rl(env,'setup:'+ip,5,900))throw H(429,'Demasiados intentos');
    await hit(env,'setup:'+ip);
    if(!eq(String(b.token||''),env.SETUP_TOKEN)){log('setup_fail',ip);throw H(403,'Token inválido')}
    const user=String(b.user||'').trim(),pw=String(b.password||'');
    if(!/^[\w.-]{3,32}$/.test(user)||pw.length<12||pw.length>200)throw H(400,'Usuario de 3-32 caracteres y contraseña de mínimo 12');
    const salt=rnd(16);
    await DB.prepare('INSERT INTO admin(id,user,salt,hash) VALUES(1,?,?,?)').bind(user,salt,await pbk(pw,salt)).run();
    log('setup_ok',ip);return J({ok:1})}

  if(p==='login'&&m==='POST'){
    const b=await body();
    if(await rl(env,'login:'+ip,5,900)){log('login_blocked',ip);throw H(429,'Demasiados intentos. Espera 15 minutos.')}
    const a=await DB.prepare('SELECT user,salt,hash FROM admin WHERE id=1').first();
    const h=await pbk(String(b.password||'').slice(0,200),a?a.salt:'00'.repeat(16));
    if(!a||String(b.user||'')!==a.user||!eq(h,a.hash)){await hit(env,'login:'+ip);log('login_fail',ip);throw H(401,'Usuario o contraseña incorrectos')}
    await DB.prepare('DELETE FROM sessions WHERE exp<?').bind(Date.now()).run();
    const t=rnd(32),csrf=rnd(16);
    await DB.prepare('INSERT INTO sessions(id,csrf,exp) VALUES(?,?,?)').bind(await sha(t),csrf,Date.now()+8*36e5).run();
    log('login_ok',ip);
    return J({csrf},200,{'set-cookie':`__Host-sb=${t}; Path=/; Max-Age=28800; HttpOnly; Secure; SameSite=Strict`})}

  if(p==='me'&&m==='GET'){x=await sess();if(!x)throw H(401,'No autorizado');return J({csrf:x.csrf})}
  if(p==='logout'&&m==='POST'){await admin();await DB.prepare('DELETE FROM sessions WHERE id=?').bind(await sha(ck[1])).run();return J({ok:1},200,{'set-cookie':'__Host-sb=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict'})}

  if(p==='products'&&m==='GET'){
    const {results}=await DB.prepare('SELECT id,name,price,stock,cat,feat,img FROM products ORDER BY rowid').all();
    return J({products:results.map(r=>({...r,feat:!!r.feat}))})}
  if(p==='products'&&m==='POST'){await admin();const id='p'+rnd(5);
    await DB.prepare('INSERT INTO products(id,name,price,stock,cat,feat,img) VALUES(?,?,?,?,?,?,?)').bind(id,...prod(await body())).run();return J({id},201)}
  if((x=p.match(/^products\/(p[a-z0-9]{1,20})$/))){
    await admin();
    if(m==='PUT'){await DB.prepare('UPDATE products SET name=?,price=?,stock=?,cat=?,feat=?,img=? WHERE id=?').bind(...prod(await body()),x[1]).run();return J({ok:1})}
    if(m==='DELETE'){await DB.prepare('DELETE FROM products WHERE id=?').bind(x[1]).run();return J({ok:1})}}

  // El servidor recalcula precios y descuenta stock: el cliente solo envía ids y cantidades.
  if(p==='orders'&&m==='POST'){
    const b=await body();
    if(await rl(env,'ord:'+ip,8,3600))throw H(429,'Demasiados pedidos. Intenta más tarde.');
    await hit(env,'ord:'+ip);
    const name=clean(b.name,80),phone=String(b.phone||'').trim(),city=clean(b.city,80);
    if(!name||!city||!/^[+\d][\d\s().-]{6,19}$/.test(phone)||!Array.isArray(b.items)||!b.items.length||b.items.length>40)throw H(400,'Revisa tus datos');
    const q=new Map();
    for(const i of b.items){const n=Math.floor(+i.q);if(!PID.test(String(i.id))||!(n>=1&&n<=999))throw H(400,'Carrito inválido');q.set(i.id,(q.get(i.id)||0)+n)}
    const ids=[...q.keys()];
    const {results}=await DB.prepare(`SELECT id,name,price,stock FROM products WHERE id IN (${ids.map(()=>'?').join()})`).bind(...ids).all();
    if(results.length!==ids.length)throw H(409,'Un producto ya no está disponible');
    let total=0;
    const items=results.map(r=>{const n=q.get(r.id);if(r.stock<n)throw H(409,`Existencias insuficientes: ${r.name}`);total=Math.round((total+r.price*n)*100)/100;return{pid:r.id,name:r.name,price:r.price,q:n}});
    const id='SB-'+Date.now().toString(36).toUpperCase()+rnd(2).toUpperCase();
    try{await DB.batch([DB.prepare('INSERT INTO orders(id,t,name,phone,city,items,total) VALUES(?,?,?,?,?,?,?)').bind(id,Date.now(),name,phone,city,JSON.stringify(items),total),
      ...items.map(i=>DB.prepare('UPDATE products SET stock=stock-? WHERE id=?').bind(i.q,i.pid))])}
    catch{throw H(409,'Existencias insuficientes')}
    return J({id,total,items:items.map(({name,price,q})=>({name,price,q}))},201)}

  if(p==='events'&&m==='POST'){
    const b=await body();
    if(!PID.test(String(b.id))||await rl(env,'ev:'+ip,60,3600))return J({ok:1});
    await hit(env,'ev:'+ip);
    const r=await DB.prepare('SELECT name FROM products WHERE id=?').bind(b.id).first();
    if(r)await DB.prepare('INSERT INTO events(t,name) VALUES(?,?)').bind(Date.now(),r.name).run();
    return J({ok:1})}

  if(p==='stats'&&m==='GET'){
    await admin();
    const os=(await DB.prepare('SELECT id,t date,name,phone,city,items,total FROM orders ORDER BY t DESC LIMIT 20').all()).results.map(o=>({...o,items:JSON.parse(o.items)}));
    const a=await DB.prepare('SELECT COUNT(*) n,COALESCE(SUM(total),0) s FROM orders').first();
    const top=(await DB.prepare('SELECT name,COUNT(*) n FROM events GROUP BY name ORDER BY n DESC LIMIT 8').all()).results;
    const ec=(await DB.prepare('SELECT COUNT(*) n FROM events').first()).n;
    return J({orders:os,oc:a.n,sales:a.s,top,ec})}
  if(p==='orders'&&m==='DELETE'){await admin();await DB.batch([DB.prepare('DELETE FROM orders'),DB.prepare('DELETE FROM events')]);log('orders_reset',ip);return J({ok:1})}

  throw H(404,'No encontrado');
}
